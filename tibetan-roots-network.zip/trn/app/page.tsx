import Link from "next/link";

export default function HomePage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-20">
      <div className="max-w-prose">
        <h1 className="font-display text-5xl leading-tight mb-6">
          Find your region. Find your people.
        </h1>
        <p className="text-lg text-stone mb-8">
          Tibetan Roots Network is a heritage record for the diaspora —
          trace your family to a region and settlement, connect with others
          from the same place, and keep the stories that would otherwise be
          lost.
        </p>
        <div className="flex gap-4">
          <Link
            href="/sign-in"
            className="rounded-full bg-ink text-snow px-6 py-3 hover:bg-ink/90"
          >
            Build your heritage record
          </Link>
          <Link
            href="/map"
            className="rounded-full border border-ink px-6 py-3 hover:bg-ink/5"
          >
            Explore the Roots Map
          </Link>
        </div>
      </div>

      <p className="text-sm text-stone mt-16 max-w-prose">
        This is not a social feed. There&apos;s no messaging, no live
        streaming, no donations processed here — just a place to record and
        find where your family comes from.
      </p>
    </div>
  );
}
