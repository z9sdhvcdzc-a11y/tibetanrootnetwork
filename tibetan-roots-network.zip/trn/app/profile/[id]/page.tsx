import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function PublicProfilePage({
  params
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  // RLS decides what's visible: public, an accepted connection, or the
  // owner. A row simply won't come back if none of those apply — that's
  // enforced at the database, not re-implemented here.
  const { data: user } = await supabase
    .from("users")
    .select("id, display_name")
    .eq("id", params.id)
    .single();

  if (!user) {
    notFound();
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select(
      "bio, languages, regions:origin_region_id(name_english, name_tibetan), settlements:origin_settlement_id(name, country)"
    )
    .eq("user_id", params.id)
    .maybeSingle();

  if (!profile) {
    return (
      <div className="max-w-lg mx-auto px-6 py-16">
        <h1 className="font-display text-3xl mb-2">{user!.display_name}</h1>
        <p className="text-stone">
          This profile is private, or hasn&apos;t been set up yet.
        </p>
      </div>
    );
  }

  const region = Array.isArray(profile.regions) ? profile.regions[0] : profile.regions;
  const settlement = Array.isArray(profile.settlements)
    ? profile.settlements[0]
    : profile.settlements;

  return (
    <div className="max-w-lg mx-auto px-6 py-16">
      <h1 className="font-display text-3xl mb-1">{user!.display_name}</h1>
      <p className="text-stone mb-6">
        {region?.name_english ?? "Region not shared"}
        {settlement ? ` · ${settlement.name}, ${settlement.country}` : ""}
      </p>
      {profile.bio && <p className="mb-6 leading-relaxed">{profile.bio}</p>}
      {profile.languages?.length > 0 && (
        <p className="text-sm text-stone">
          Speaks: {profile.languages.join(", ")}
        </p>
      )}
    </div>
  );
}
