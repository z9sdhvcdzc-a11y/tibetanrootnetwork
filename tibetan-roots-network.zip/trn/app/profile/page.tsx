import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { updateProfile } from "@/lib/actions";

export default async function ProfilePage() {
  const supabase = createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/sign-in");
  }

  const { data: appUser } = await supabase
    .from("users")
    .select("id, display_name")
    .eq("auth_id", user!.id)
    .single();

  if (!appUser) {
    redirect("/sign-in");
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select(
      "bio, visibility, languages, origin_region_id, origin_settlement_id, regions:origin_region_id(name_english), settlements:origin_settlement_id(name, country)"
    )
    .eq("user_id", appUser!.id)
    .maybeSingle();

  if (!profile) {
    redirect("/onboarding");
  }

  const region = Array.isArray(profile.regions) ? profile.regions[0] : profile.regions;
  const settlement = Array.isArray(profile.settlements)
    ? profile.settlements[0]
    : profile.settlements;

  return (
    <div className="max-w-lg mx-auto px-6 py-16">
      <h1 className="font-display text-3xl mb-1">{appUser!.display_name}</h1>
      <p className="text-stone mb-8">
        {region?.name_english ?? "Region not set"}
        {settlement ? ` · ${settlement.name}, ${settlement.country}` : ""}
      </p>

      <form action={updateProfile} className="space-y-6">
        <label className="block">
          <span className="text-sm text-stone">About</span>
          <textarea
            name="bio"
            rows={4}
            defaultValue={profile.bio ?? ""}
            className="mt-1 w-full rounded-md border border-stone/40 px-3 py-2 bg-snow"
            placeholder="A short note about your family's story, in your own words."
          />
        </label>

        <fieldset>
          <legend className="text-sm text-stone mb-2">Who can see your profile?</legend>
          <div className="space-y-2">
            {(["private", "connections", "public"] as const).map((v) => (
              <label key={v} className="flex items-center gap-2">
                <input
                  type="radio"
                  name="visibility"
                  value={v}
                  defaultChecked={profile.visibility === v}
                />
                {v === "private" && "Only me"}
                {v === "connections" && "People I connect with"}
                {v === "public" && "Anyone"}
              </label>
            ))}
          </div>
        </fieldset>

        <button
          type="submit"
          className="w-full rounded-full bg-ink text-snow px-4 py-2.5 hover:bg-ink/90"
        >
          Save changes
        </button>
      </form>
    </div>
  );
}
