import dynamic from "next/dynamic";
import { createClient } from "@/lib/supabase/server";
import type { Settlement } from "@/components/MapView";

const MapView = dynamic(() => import("@/components/MapView"), {
  ssr: false,
  loading: () => (
    <div className="h-[560px] w-full rounded-lg border border-stone/20 flex items-center justify-center text-stone">
      Loading map…
    </div>
  )
});

export default async function MapPage() {
  const supabase = createClient();

  const { data, error } = await supabase
    .from("settlements")
    .select("id, name, country, lat, lng, type, regions:region_id(name_english)")
    .order("name");

  const settlements: Settlement[] =
    data?.map((s) => {
      const region = Array.isArray(s.regions) ? s.regions[0] : s.regions;
      return {
        id: s.id,
        name: s.name,
        country: s.country,
        lat: s.lat,
        lng: s.lng,
        type: s.type,
        region_name: region?.name_english ?? null
      };
    }) ?? [];

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <h1 className="font-display text-3xl mb-2">Roots Map</h1>
      <p className="text-stone mb-8 max-w-prose">
        Settlements, monasteries, and schools of the diaspora. Click a point
        to see who and what is connected to that place.
      </p>

      {error && (
        <p className="text-clay mb-4">
          Couldn&apos;t load the map right now. Try refreshing.
        </p>
      )}

      <MapView settlements={settlements} />

      <div className="flex gap-6 mt-4 text-sm text-stone">
        <LegendDot color="#E1972E" label="Settlement" />
        <LegendDot color="#A94A3F" label="Monastery" />
        <LegendDot color="#3F5C4E" label="School" />
        <LegendDot color="#1C1A2E" label="Association" />
      </div>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span
        className="inline-block w-2.5 h-2.5 rounded-full"
        style={{ backgroundColor: color }}
      />
      {label}
    </span>
  );
}
