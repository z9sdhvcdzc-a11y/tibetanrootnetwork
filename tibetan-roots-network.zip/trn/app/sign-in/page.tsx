"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SignInPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const supabase = createClient();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/onboarding`
      }
    });
    if (error) {
      setError(error.message);
    } else {
      setSent(true);
    }
  }

  return (
    <div className="max-w-sm mx-auto px-6 py-20">
      <h1 className="font-display text-3xl mb-2">Sign in</h1>
      <p className="text-stone mb-8">
        We&apos;ll email you a link — no password to remember.
      </p>

      {sent ? (
        <p className="rounded-lg bg-juniper/10 border border-juniper/30 px-4 py-3 text-juniper">
          Check {email} for a sign-in link.
        </p>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="text-sm text-stone">Email</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-md border border-stone/40 px-3 py-2 bg-snow"
              placeholder="you@example.com"
            />
          </label>
          {error && <p className="text-clay text-sm">{error}</p>}
          <button
            type="submit"
            className="w-full rounded-full bg-ink text-snow px-4 py-2.5 hover:bg-ink/90"
          >
            Send sign-in link
          </button>
        </form>
      )}
    </div>
  );
}
