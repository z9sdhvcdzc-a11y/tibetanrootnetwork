import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: NextRequest) {
  const supabase = createClient();
  const regionId = request.nextUrl.searchParams.get("region");

  let query = supabase
    .from("settlements")
    .select("id, name, country, lat, lng, type, region_id")
    .order("name");

  if (regionId) {
    query = query.eq("region_id", regionId);
  }

  const { data, error } = await query;

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ settlements: data });
}
