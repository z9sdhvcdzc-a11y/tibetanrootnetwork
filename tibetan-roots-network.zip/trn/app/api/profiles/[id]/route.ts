import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(
  _request: Request,
  { params }: { params: { id: string } }
) {
  const supabase = createClient();

  // No manual visibility check here on purpose — RLS on `profiles` is the
  // single source of truth for who can read this row. A private profile
  // simply returns no row for a caller who isn't the owner/connection.
  const { data, error } = await supabase
    .from("profiles")
    .select(
      "user_id, bio, languages, visibility, origin_region_id, origin_settlement_id"
    )
    .eq("user_id", params.id)
    .maybeSingle();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  if (!data) {
    return NextResponse.json({ error: "Not found or not visible" }, { status: 404 });
  }

  return NextResponse.json({ profile: data });
}
