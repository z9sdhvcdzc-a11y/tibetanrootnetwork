export default function OrganizationsPlaceholderPage() {
  return (
    <div className="max-w-lg mx-auto px-6 py-20">
      <h1 className="font-display text-3xl mb-2">Organizations</h1>
      <p className="text-stone">
        The Organization Directory (M4) is next in the build order — schema
        and RLS are already in place, this page ships when that module is
        implemented.
      </p>
    </div>
  );
}
