import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { saveOnboarding } from "@/lib/actions";

export default async function OnboardingPage() {
  const supabase = createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/sign-in");
  }

  const { data: regions } = await supabase
    .from("regions")
    .select("id, name_english, name_tibetan")
    .order("name_english");

  const { data: settlements } = await supabase
    .from("settlements")
    .select("id, name, country, region_id")
    .order("name");

  return (
    <div className="max-w-lg mx-auto px-6 py-16">
      <h1 className="font-display text-3xl mb-2">Where do your roots trace to?</h1>
      <p className="text-stone mb-8">
        This sets your default heritage record. You control who can see it —
        change it any time from your profile.
      </p>

      <form action={saveOnboarding} className="space-y-6">
        <label className="block">
          <span className="text-sm text-stone">Region of origin</span>
          <select
            name="origin_region_id"
            className="mt-1 w-full rounded-md border border-stone/40 px-3 py-2 bg-snow"
            defaultValue=""
          >
            <option value="">Prefer not to say / unsure</option>
            {regions?.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name_english}
                {r.name_tibetan ? ` — ${r.name_tibetan}` : ""}
              </option>
            ))}
          </select>
        </label>

        <label className="block">
          <span className="text-sm text-stone">Settlement, monastery, or school</span>
          <select
            name="origin_settlement_id"
            className="mt-1 w-full rounded-md border border-stone/40 px-3 py-2 bg-snow"
            defaultValue=""
          >
            <option value="">Not applicable</option>
            {settlements?.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.country})
              </option>
            ))}
          </select>
        </label>

        <label className="block">
          <span className="text-sm text-stone">Languages you speak (comma-separated)</span>
          <input
            name="languages"
            className="mt-1 w-full rounded-md border border-stone/40 px-3 py-2 bg-snow"
            placeholder="Tibetan, English, Hindi"
          />
        </label>

        <fieldset>
          <legend className="text-sm text-stone mb-2">Who can see your profile?</legend>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input type="radio" name="visibility" value="private" defaultChecked />
              Only me
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" name="visibility" value="connections" />
              People I connect with
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" name="visibility" value="public" />
              Anyone
            </label>
          </div>
        </fieldset>

        <button
          type="submit"
          className="w-full rounded-full bg-ink text-snow px-4 py-2.5 hover:bg-ink/90"
        >
          Save and continue
        </button>
      </form>
    </div>
  );
}
