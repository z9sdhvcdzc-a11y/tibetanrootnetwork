import type { Metadata } from "next";
import { Spectral, Karla } from "next/font/google";
import Link from "next/link";
import "./globals.css";
import NavAuth from "@/components/NavAuth";

const display = Spectral({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-display"
});

const body = Karla({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-body"
});

export const metadata: Metadata = {
  title: "Tibetan Roots Network",
  description:
    "Find your region, your settlement, your people — a heritage network for the Tibetan diaspora."
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body className="font-body min-h-screen flex flex-col">
        <header className="border-b border-stone/20">
          <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
            <Link href="/" className="font-display text-xl tracking-tight">
              Tibetan Roots Network
            </Link>
            <nav className="flex items-center gap-6 text-sm">
              <Link href="/map" className="hover:text-clay">
                Roots Map
              </Link>
              <Link href="/organizations" className="hover:text-clay">
                Organizations
              </Link>
              <NavAuth />
            </nav>
          </div>
        </header>
        <main className="flex-1">{children}</main>
        <footer className="border-t border-stone/20 mt-16">
          <div className="max-w-5xl mx-auto px-6 py-8 text-sm text-stone">
            Tibetan Roots Network — a heritage record, not a social feed.
          </div>
        </footer>
      </body>
    </html>
  );
}
