"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import type { User } from "@supabase/supabase-js";

export default function NavAuth() {
  const [user, setUser] = useState<User | null>(null);
  const supabase = createClient();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, [supabase]);

  if (!user) {
    return (
      <Link
        href="/sign-in"
        className="rounded-full bg-ink text-snow px-4 py-1.5 hover:bg-ink/90"
      >
        Sign in
      </Link>
    );
  }

  return (
    <div className="flex items-center gap-4">
      <Link href="/profile" className="hover:text-clay">
        My profile
      </Link>
      <button
        onClick={() => supabase.auth.signOut()}
        className="text-stone hover:text-clay"
      >
        Sign out
      </button>
    </div>
  );
}
