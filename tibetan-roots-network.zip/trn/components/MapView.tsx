"use client";

import { MapContainer, TileLayer, CircleMarker, Popup } from "react-leaflet";
import Link from "next/link";

export type Settlement = {
  id: string;
  name: string;
  country: string;
  lat: number;
  lng: number;
  type: string;
  region_name: string | null;
};

const typeColor: Record<string, string> = {
  settlement: "#E1972E", // marigold
  monastery: "#A94A3F", // clay
  school: "#3F5C4E", // juniper
  association: "#1C1A2E", // ink
  other: "#8A8577" // stone
};

export default function MapView({ settlements }: { settlements: Settlement[] }) {
  return (
    <MapContainer
      center={[28, 84]}
      zoom={4}
      scrollWheelZoom
      className="h-[560px] w-full rounded-lg border border-stone/20"
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {settlements.map((s) => (
        <CircleMarker
          key={s.id}
          center={[s.lat, s.lng]}
          radius={8}
          pathOptions={{
            color: typeColor[s.type] ?? typeColor.other,
            fillColor: typeColor[s.type] ?? typeColor.other,
            fillOpacity: 0.85
          }}
        >
          <Popup>
            <div className="font-body">
              <p className="font-semibold">{s.name}</p>
              <p className="text-sm text-stone">
                {s.country}
                {s.region_name ? ` · ${s.region_name}` : ""}
              </p>
              <Link
                href={`/organizations?settlement=${s.id}`}
                className="text-sm text-clay underline"
              >
                See linked organizations
              </Link>
            </div>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
