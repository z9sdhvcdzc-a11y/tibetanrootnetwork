-- Row Level Security
-- Fully implemented for M1 (users, profiles) and M2 (regions, settlements) —
-- these are the modules being built this pass.
-- Every other table has RLS *enabled* with no policies yet, which means
-- default-deny: nothing is readable/writable via the API until that
-- table's owning module adds explicit policies. Never leave a table with
-- RLS disabled as a placeholder — enabled-with-no-policies is the safe
-- default; disabled is an open table.

-- ---------- helper functions ----------
create or replace function current_app_user_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select id from users where auth_id = auth.uid();
$$;

create or replace function is_moderator_or_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from users
    where auth_id = auth.uid()
      and role in ('moderator', 'admin')
  );
$$;

-- ========== M1: users ==========
alter table users enable row level security;

create policy "users can read own row"
  on users for select
  using (auth_id = auth.uid());

create policy "moderators and admins can read all users"
  on users for select
  using (is_moderator_or_admin());

create policy "users can update own row (not role)"
  on users for update
  using (auth_id = auth.uid())
  with check (auth_id = auth.uid() and role = 'member');

-- Row creation happens via a security-definer trigger on auth.users signup
-- (see 0003_handle_new_user.sql), not directly by client insert.

-- ========== M1: profiles ==========
alter table profiles enable row level security;

create policy "public profiles readable by anyone"
  on profiles for select
  using (visibility = 'public');

create policy "connections-only profiles readable by accepted connections"
  on profiles for select
  using (
    visibility = 'connections'
    and exists (
      select 1 from connections c
      where c.status = 'accepted'
        and (
          (c.requester_id = current_app_user_id() and c.target_id = profiles.user_id)
          or (c.target_id = current_app_user_id() and c.requester_id = profiles.user_id)
        )
    )
  );

create policy "owner can always read own profile"
  on profiles for select
  using (user_id = current_app_user_id());

create policy "moderators and admins can read all profiles"
  on profiles for select
  using (is_moderator_or_admin());

create policy "owner can insert own profile"
  on profiles for insert
  with check (user_id = current_app_user_id());

create policy "owner can update own profile"
  on profiles for update
  using (user_id = current_app_user_id())
  with check (user_id = current_app_user_id());

-- ========== M2: regions ==========
alter table regions enable row level security;

create policy "regions are public reference data"
  on regions for select
  using (true);

create policy "only admins can write regions"
  on regions for insert
  with check (is_moderator_or_admin());

create policy "only admins can update regions"
  on regions for update
  using (is_moderator_or_admin())
  with check (is_moderator_or_admin());

-- ========== M2: settlements ==========
alter table settlements enable row level security;

create policy "settlements are public reference data"
  on settlements for select
  using (true);

create policy "only admins can write settlements"
  on settlements for insert
  with check (is_moderator_or_admin());

create policy "only admins can update settlements"
  on settlements for update
  using (is_moderator_or_admin())
  with check (is_moderator_or_admin());

-- ========== later modules: RLS enabled, default-deny ==========
-- M4
alter table organizations enable row level security;
alter table org_memberships enable row level security;
-- M3
alter table family_trees enable row level security;
alter table family_nodes enable row level security;
alter table family_edges enable row level security;
-- M5
alter table archive_entries enable row level security;
-- M7
alter table events enable row level security;
alter table event_rsvps enable row level security;
-- M6
alter table connections enable row level security;
-- M9
alter table notifications enable row level security;
-- M8
alter table moderation_actions enable row level security;

-- NOTE for the next module's implementer: `connections` needs at least a
-- baseline read/insert policy before M2's "connections-only profile" policy
-- above is reachable end-to-end. Add it when M6 is implemented — until
-- then, connections-gated profile visibility has no way to be populated,
-- which is a safe (if inert) default.
