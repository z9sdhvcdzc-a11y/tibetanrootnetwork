-- Tibetan Roots Network — core schema
-- Modules: M1 Identity, M2 Roots Map, M3 Genealogy, M4 Orgs,
--          M5 Archive, M6 Discovery, M7 Events, M8 Admin, M9 Notifications
--
-- Build order note: M1 + M2 tables below are fully implemented and RLS'd
-- in 0002_rls.sql. Later-module tables are created now (so foreign keys
-- resolve and no schema migration blocks a future module) but ship with
-- default-deny RLS until their module is implemented — see 0002_rls.sql.

create extension if not exists "pg_trgm";
create extension if not exists "postgis";

-- ---------- enums ----------
create type platform_role as enum ('member', 'moderator', 'admin');
create type org_role as enum ('owner', 'editor');
create type org_verified_status as enum ('pending', 'verified', 'rejected');
create type org_type as enum ('settlement', 'association', 'monastery', 'school', 'other');
create type visibility as enum ('public', 'connections', 'private');
create type archive_type as enum ('oral_history', 'document', 'language_resource', 'photo');
create type review_status as enum ('pending', 'approved', 'rejected');
create type connection_status as enum ('pending', 'accepted', 'declined');
create type rsvp_status as enum ('going', 'interested', 'cancelled');

-- ---------- M1: Identity & Profiles ----------
create table users (
  id uuid primary key default gen_random_uuid(),
  auth_id uuid not null unique references auth.users(id) on delete cascade,
  display_name text not null,
  email text not null,
  role platform_role not null default 'member',
  privacy_default visibility not null default 'private',
  created_at timestamptz not null default now()
);

create table regions (
  id uuid primary key default gen_random_uuid(),
  name_tibetan text,
  name_english text not null,
  parent_region_id uuid references regions(id) on delete set null,
  geo_boundary geometry(Geometry, 4326),
  historical_period text,
  created_at timestamptz not null default now()
);

create table settlements (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  country text not null,
  region_id uuid references regions(id) on delete set null,
  lat double precision not null,
  lng double precision not null,
  founded_year int,
  type org_type not null default 'settlement',
  created_at timestamptz not null default now()
);

create table profiles (
  user_id uuid primary key references users(id) on delete cascade,
  bio text,
  origin_region_id uuid references regions(id) on delete set null,
  origin_settlement_id uuid references settlements(id) on delete set null,
  languages text[] not null default '{}',
  photo_url text,
  visibility visibility not null default 'private',
  updated_at timestamptz not null default now()
);

-- ---------- M4: Organization Directory ----------
create table organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type org_type not null,
  settlement_id uuid references settlements(id) on delete set null,
  description text,
  verified_status org_verified_status not null default 'pending',
  verified_by uuid references users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table org_memberships (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  org_role org_role not null default 'editor',
  status text not null default 'active',
  created_at timestamptz not null default now(),
  unique (org_id, user_id)
);

-- ---------- M3: Genealogy & Family Tree ----------
create table family_trees (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references users(id) on delete cascade,
  name text not null,
  visibility visibility not null default 'private',
  created_at timestamptz not null default now()
);

create table family_nodes (
  id uuid primary key default gen_random_uuid(),
  tree_id uuid not null references family_trees(id) on delete cascade,
  linked_user_id uuid references users(id) on delete set null,
  full_name text not null,
  birth_year int,
  origin_settlement_id uuid references settlements(id) on delete set null,
  notes text,
  privacy_tier visibility not null default 'private',
  created_at timestamptz not null default now()
);

create table family_edges (
  id uuid primary key default gen_random_uuid(),
  tree_id uuid not null references family_trees(id) on delete cascade,
  parent_node_id uuid not null references family_nodes(id) on delete cascade,
  child_node_id uuid not null references family_nodes(id) on delete cascade,
  relation_type text not null default 'parent',
  check (parent_node_id <> child_node_id)
);

-- ---------- M5: Cultural Archive ----------
create table archive_entries (
  id uuid primary key default gen_random_uuid(),
  contributor_id uuid not null references users(id) on delete cascade,
  type archive_type not null,
  title text not null,
  body_text text,
  media_url text,
  region_id uuid references regions(id) on delete set null,
  privacy_tier visibility not null default 'public',
  status review_status not null default 'pending',
  reviewed_by uuid references users(id) on delete set null,
  created_at timestamptz not null default now()
);

-- ---------- M7: Events ----------
create table events (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  title text not null,
  description text,
  location text,
  start_time timestamptz not null,
  end_time timestamptz,
  created_at timestamptz not null default now()
);

create table event_rsvps (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references events(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  status rsvp_status not null default 'going',
  created_at timestamptz not null default now(),
  unique (event_id, user_id)
);

-- ---------- M6: Discovery (connections, not messaging) ----------
create table connections (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references users(id) on delete cascade,
  target_id uuid not null references users(id) on delete cascade,
  status connection_status not null default 'pending',
  created_at timestamptz not null default now(),
  check (requester_id <> target_id),
  unique (requester_id, target_id)
);

-- ---------- M9: Notifications ----------
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  type text not null,
  payload jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

-- ---------- M8: Admin & Moderation ----------
create table moderation_actions (
  id uuid primary key default gen_random_uuid(),
  moderator_id uuid not null references users(id) on delete cascade,
  target_type text not null,
  target_id uuid not null,
  action text not null,
  reason text,
  created_at timestamptz not null default now()
);

-- ---------- indexes ----------
create index idx_settlements_region on settlements(region_id);
create index idx_profiles_origin_region on profiles(origin_region_id, visibility);
create index idx_family_nodes_name_trgm on family_nodes using gin (full_name gin_trgm_ops);
create index idx_org_name_trgm on organizations using gin (name gin_trgm_ops);
create index idx_archive_region on archive_entries(region_id, privacy_tier, status);
create index idx_events_org on events(org_id, start_time);
create index idx_notifications_user on notifications(user_id, read_at);
