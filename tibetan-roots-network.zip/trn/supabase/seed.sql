-- Starter reference data. Extend via the admin console once M8 ships;
-- for now this gives the Roots Map something real to render.

insert into regions (name_english, name_tibetan) values
  ('U-Tsang', 'དབུས་གཙང་'),
  ('Kham', 'ཁམས་'),
  ('Amdo', 'ཨ༌མདོ་');

insert into settlements (name, country, region_id, lat, lng, founded_year, type)
select 'Dharamshala (McLeod Ganj)', 'India', r.id, 32.2432, 76.3234, 1960, 'settlement'
from regions r where r.name_english = 'U-Tsang'
union all
select 'Bylakuppe', 'India', r.id, 12.3833, 76.1333, 1961, 'settlement'
from regions r where r.name_english = 'Kham'
union all
select 'Kathmandu Tibetan Settlements', 'Nepal', r.id, 27.7172, 85.3240, 1960, 'settlement'
from regions r where r.name_english = 'U-Tsang'
union all
select 'Namdroling Monastery', 'India', r.id, 12.3894, 76.1444, 1963, 'monastery'
from regions r where r.name_english = 'Kham'
union all
select 'Dolanji Settlement', 'India', r.id, 31.0000, 77.2000, 1967, 'settlement'
from regions r where r.name_english = 'Amdo';
