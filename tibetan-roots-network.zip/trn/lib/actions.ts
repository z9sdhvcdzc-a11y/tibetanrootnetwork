"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

const onboardingSchema = z.object({
  origin_region_id: z.string().uuid().optional().or(z.literal("")),
  origin_settlement_id: z.string().uuid().optional().or(z.literal("")),
  languages: z.string().optional(),
  visibility: z.enum(["public", "connections", "private"])
});

export async function saveOnboarding(formData: FormData) {
  const supabase = createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/sign-in");
  }

  const parsed = onboardingSchema.safeParse({
    origin_region_id: formData.get("origin_region_id"),
    origin_settlement_id: formData.get("origin_settlement_id"),
    languages: formData.get("languages"),
    visibility: formData.get("visibility")
  });

  if (!parsed.success) {
    throw new Error("Please check the form — something didn't look right.");
  }

  const { data: appUser, error: userLookupError } = await supabase
    .from("users")
    .select("id")
    .eq("auth_id", user!.id)
    .single();

  if (userLookupError || !appUser) {
    throw new Error("We couldn't find your account record. Try signing in again.");
  }

  const languages = parsed.data.languages
    ? parsed.data.languages.split(",").map((l) => l.trim()).filter(Boolean)
    : [];

  const { error } = await supabase.from("profiles").upsert({
    user_id: appUser.id,
    origin_region_id: parsed.data.origin_region_id || null,
    origin_settlement_id: parsed.data.origin_settlement_id || null,
    languages,
    visibility: parsed.data.visibility,
    updated_at: new Date().toISOString()
  });

  if (error) {
    throw new Error(error.message);
  }

  revalidatePath("/profile");
  redirect("/profile");
}

const profileUpdateSchema = z.object({
  bio: z.string().max(2000).optional(),
  visibility: z.enum(["public", "connections", "private"])
});

export async function updateProfile(formData: FormData) {
  const supabase = createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/sign-in");
  }

  const parsed = profileUpdateSchema.safeParse({
    bio: formData.get("bio") ?? undefined,
    visibility: formData.get("visibility")
  });

  if (!parsed.success) {
    throw new Error("Please check the form — something didn't look right.");
  }

  const { data: appUser } = await supabase
    .from("users")
    .select("id")
    .eq("auth_id", user!.id)
    .single();

  if (!appUser) {
    throw new Error("We couldn't find your account record.");
  }

  const { error } = await supabase
    .from("profiles")
    .update({
      bio: parsed.data.bio,
      visibility: parsed.data.visibility,
      updated_at: new Date().toISOString()
    })
    .eq("user_id", appUser.id);

  if (error) {
    throw new Error(error.message);
  }

  revalidatePath("/profile");
}
