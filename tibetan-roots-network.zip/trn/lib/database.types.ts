// Hand-written subset covering M1 (users/profiles) and M2 (regions/settlements).
// Regenerate the full file after deploying migrations:
//   npx supabase gen types typescript --project-id <ref> > lib/database.types.ts

export type Visibility = "public" | "connections" | "private";
export type PlatformRole = "member" | "moderator" | "admin";
export type OrgType = "settlement" | "association" | "monastery" | "school" | "other";

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          auth_id: string;
          display_name: string;
          email: string;
          role: PlatformRole;
          privacy_default: Visibility;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["users"]["Row"]>;
        Update: Partial<Database["public"]["Tables"]["users"]["Row"]>;
      };
      profiles: {
        Row: {
          user_id: string;
          bio: string | null;
          origin_region_id: string | null;
          origin_settlement_id: string | null;
          languages: string[];
          photo_url: string | null;
          visibility: Visibility;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["profiles"]["Row"]> & {
          user_id: string;
        };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Row"]>;
      };
      regions: {
        Row: {
          id: string;
          name_tibetan: string | null;
          name_english: string;
          parent_region_id: string | null;
          historical_period: string | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["regions"]["Row"]>;
        Update: Partial<Database["public"]["Tables"]["regions"]["Row"]>;
      };
      settlements: {
        Row: {
          id: string;
          name: string;
          country: string;
          region_id: string | null;
          lat: number;
          lng: number;
          founded_year: number | null;
          type: OrgType;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["settlements"]["Row"]>;
        Update: Partial<Database["public"]["Tables"]["settlements"]["Row"]>;
      };
    };
  };
}
