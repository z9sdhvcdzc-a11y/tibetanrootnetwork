# Tibetan Roots Network

This build covers **M1 (Identity & Profiles)** and **M2 (Roots Map)** in full,
per the agreed build order. The database schema for every module (M3–M9)
is already created with RLS *enabled and default-deny*, so later modules
plug in without a breaking migration — but only M1/M2 have working UI and
policies right now. `/organizations` is a placeholder for M4, built next.

## What's actually working

- Email magic-link auth (Supabase Auth)
- Onboarding: set origin region/settlement, languages, profile visibility
- Profile view/edit, with three-tier privacy (private / connections / public)
- Public profile view that respects visibility via **database-level RLS**,
  not app-layer checks
- Interactive Roots Map (Leaflet) plotting settlements/monasteries/schools,
  seeded with 5 real starting locations
- REST endpoints: `GET /api/regions`, `GET /api/settlements`,
  `GET /api/profiles/:id`

## 1. Create the Supabase project

1. Create a project at supabase.com.
2. In the SQL editor, run the three migration files **in order**:
   - `supabase/migrations/0001_schema.sql`
   - `supabase/migrations/0002_rls.sql`
   - `supabase/migrations/0003_handle_new_user.sql`
3. Run `supabase/seed.sql` to load starter regions/settlements.
4. Under Authentication → URL Configuration, set your site URL and add
   `https://<your-vercel-domain>/onboarding` as a redirect URL (and
   `http://localhost:3000/onboarding` for local dev).
5. Authentication → Providers: Email is enabled by default; magic link
   (OTP) needs no extra config.
6. Copy your Project URL and anon public key (Settings → API).

## 2. Local development

```bash
cp .env.example .env.local   # fill in the two Supabase values
npm install
npm run dev
```

Visit http://localhost:3000.

## 3. Deploy to Vercel

```bash
npm install -g vercel   # if you don't have it
vercel
```

Or via the dashboard: import this repo, set the two environment variables
(`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`) under Project
Settings → Environment Variables, deploy.

Vercel auto-detects Next.js — no build config needed.

## 4. Regenerate types after schema changes

```bash
npx supabase gen types typescript --project-id <your-ref> > lib/database.types.ts
```

`lib/database.types.ts` currently only covers the tables this pass uses
(`users`, `profiles`, `regions`, `settlements`). Regenerate it once M3/M4
land so those tables get type coverage too.

## 5. Security notes for whoever builds the next module

- Every table beyond `users`/`profiles`/`regions`/`settlements` has RLS
  **enabled with zero policies** — meaning fully locked, not fully open.
  Add explicit policies as each module ships; never disable RLS as a
  shortcut.
- `connections` has no policies yet. The "connections-only" profile
  visibility policy in `0002_rls.sql` references it but is inert until M6
  adds a policy letting users read/insert their own connection rows.
- Don't add a client-side visibility check anywhere as a substitute for an
  RLS policy — this schema assumes RLS is the only enforcement layer the
  API can't route around.

## Build order (unchanged from the PRD)

M1 → M2 → M4 → M3 → M6 → M5 → M7 → M9 → M8. Each module: schema + RLS →
API → UI → tests, gated on that module's RLS policy tests passing before
moving on.
