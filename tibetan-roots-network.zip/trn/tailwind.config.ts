import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#1C1A2E",
        parchment: "#EFE7D8",
        snow: "#FBF9F4",
        marigold: "#E1972E",
        juniper: "#3F5C4E",
        clay: "#A94A3F",
        stone: "#8A8577"
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"]
      },
      maxWidth: {
        prose: "68ch"
      }
    }
  },
  plugins: []
};

export default config;
